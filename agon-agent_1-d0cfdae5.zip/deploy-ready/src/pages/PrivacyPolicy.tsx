import { motion } from 'framer-motion';
import { Shield, Cookie, Database, Lock, Mail, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-slate-950 text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <Link to="/" className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition-colors"><ArrowLeft className="w-4 h-4" />Back to Home</Link>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-4xl font-bold mb-2">Privacy Policy</h1>
          <p className="text-slate-400 mb-8">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
          <div className="prose prose-invert max-w-none">
            <div className="bg-white/5 rounded-2xl border border-white/10 p-6 mb-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-indigo-500/20 rounded-lg"><Shield className="w-5 h-5 text-indigo-400" /></div>
                <h2 className="text-xl font-semibold m-0">Your Privacy Matters</h2>
              </div>
              <p className="text-slate-300 m-0">At GlobalNews, we are committed to protecting your privacy. This policy explains how we collect, use, and safeguard your information.</p>
            </div>
            <section className="mb-8">
              <div className="flex items-center gap-3 mb-4"><Database className="w-5 h-5 text-indigo-400" /><h2 className="text-xl font-semibold">1. Information We Collect</h2></div>
              <div className="text-slate-300 space-y-3">
                <p><strong>Account Information:</strong> When you create an account, we collect your name, email address, and password.</p>
                <p><strong>Usage Data:</strong> We collect information about how you use our service, including pages viewed and features used.</p>
                <p><strong>Device Information:</strong> We collect information about the device and browser you use to access our service.</p>
              </div>
            </section>
            <section className="mb-8">
              <div className="flex items-center gap-3 mb-4"><Lock className="w-5 h-5 text-indigo-400" /><h2 className="text-xl font-semibold">2. How We Use Your Information</h2></div>
              <ul className="text-slate-300 space-y-2 list-disc list-inside">
                <li>To provide and maintain our service</li>
                <li>To personalize your news experience</li>
                <li>To communicate with you about your account</li>
                <li>To analyze usage patterns and improve our service</li>
              </ul>
            </section>
            <section className="mb-8">
              <div className="flex items-center gap-3 mb-4"><Cookie className="w-5 h-5 text-indigo-400" /><h2 className="text-xl font-semibold">3. Cookies and Tracking</h2></div>
              <div className="text-slate-300 space-y-3">
                <p>We use cookies and similar technologies to:</p>
                <ul className="list-disc list-inside space-y-1">
                  <li><strong>Essential Cookies:</strong> Required for the website to function</li>
                  <li><strong>Analytics Cookies:</strong> Help us understand how visitors use our website</li>
                  <li><strong>Preference Cookies:</strong> Remember your settings and preferences</li>
                </ul>
              </div>
            </section>
            <section className="mb-8">
              <h2 className="text-xl font-semibold mb-4">4. Data Security</h2>
              <p className="text-slate-300">We implement industry-standard security measures to protect your data, including encryption, secure servers, and regular security audits.</p>
            </section>
            <section className="mb-8">
              <h2 className="text-xl font-semibold mb-4">5. Your Rights (GDPR)</h2>
              <ul className="text-slate-300 space-y-2 list-disc list-inside">
                <li>Access your personal data</li>
                <li>Correct inaccurate data</li>
                <li>Delete your data (right to be forgotten)</li>
                <li>Export your data in a portable format</li>
              </ul>
            </section>
            <div className="bg-white/5 rounded-2xl border border-white/10 p-6">
              <div className="flex items-center gap-3 mb-4"><Mail className="w-5 h-5 text-indigo-400" /><h2 className="text-xl font-semibold m-0">Contact Us</h2></div>
              <p className="text-slate-300 mb-4">If you have any questions about this Privacy Policy, please contact us:</p>
              <ul className="text-slate-300 space-y-1">
                <li>Email: <a href="mailto:privacy@globalnews.app" className="text-indigo-400 hover:underline">privacy@globalnews.app</a></li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
