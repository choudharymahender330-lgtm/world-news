export interface NewsArticle {
  title: string;
  description: string | null;
  url: string;
  image: string | null;
  publishedAt: string | null;
  source: string | null;
  author: string | null;
}

const RSS_FEEDS: Record<string, string[]> = {
  us: ['https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml', 'https://feeds.npr.org/1001/rss.xml', 'https://www.theguardian.com/world/rss'],
  gb: ['https://feeds.bbci.co.uk/news/rss.xml', 'https://www.theguardian.com/uk/rss'],
  de: ['https://www.spiegel.de/international/index.rss', 'https://www.dw.com/en/top-stories/s-3069/rss'],
  fr: ['https://www.france24.com/en/rss', 'https://www.lemonde.fr/en/rss.xml'],
  jp: ['https://www3.nhk.or.jp/rss/news/cat0.xml', 'https://www.japantimes.co.jp/feed/'],
  in: ['https://timesofindia.indiatimes.com/rssfeedstopstories.cms', 'https://www.thehindu.com/feeder/default.rss'],
  au: ['https://www.abc.net.au/news/feed/51120/rss.xml', 'https://www.theguardian.com/au/rss'],
  ca: ['https://www.cbc.ca/webfeed/rss/rss-canada'],
  br: ['https://feeds.folha.uol.com.br/folha/emcimadahora/rss091.xml'],
  cn: ['https://www.scmp.com/rss/91/feed'],
  default: ['https://feeds.bbci.co.uk/news/rss.xml', 'https://www.theguardian.com/world/rss'],
};

const CORS_PROXIES = ['https://api.allorigins.win/raw?url=', 'https://corsproxy.io/?'];

function parseRSS(xmlText: string, feedSource: string): NewsArticle[] {
  const parser = new DOMParser();
  const doc = parser.parseFromString(xmlText, 'text/xml');
  const items = doc.querySelectorAll('item');
  const articles: NewsArticle[] = [];

  items.forEach((item) => {
    const title = item.querySelector('title')?.textContent || '';
    const description = item.querySelector('description')?.textContent || '';
    const link = item.querySelector('link')?.textContent || '';
    const pubDate = item.querySelector('pubDate')?.textContent || '';
    const mediaContent = item.querySelector('content');
    const enclosure = item.querySelector('enclosure[type^="image"]');
    let image = mediaContent?.getAttribute('url') || enclosure?.getAttribute('url') || null;
    const cleanDescription = description.replace(/<[^>]*>/g, '').trim();

    articles.push({
      title: title.replace(/<[^>]*>/g, '').trim(),
      description: cleanDescription.substring(0, 300) || null,
      url: link,
      image,
      publishedAt: pubDate ? new Date(pubDate).toISOString() : null,
      source: feedSource,
      author: null,
    });
  });

  return articles;
}

async function fetchFromRSS(country: string): Promise<NewsArticle[]> {
  const feeds = RSS_FEEDS[country] || RSS_FEEDS['default'];
  const articles: NewsArticle[] = [];

  for (const feedUrl of feeds) {
    for (const proxy of CORS_PROXIES) {
      try {
        const response = await fetch(proxy + encodeURIComponent(feedUrl));
        if (response.ok) {
          const text = await response.text();
          const feedName = new URL(feedUrl).hostname.replace('www.', '');
          articles.push(...parseRSS(text, feedName));
          break;
        }
      } catch { continue; }
    }
  }

  const uniqueArticles = articles.filter((article, index, self) => article.url && index === self.findIndex(a => a.url === article.url));
  uniqueArticles.sort((a, b) => (!a.publishedAt ? 1 : !b.publishedAt ? -1 : new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()));
  return uniqueArticles.slice(0, 20);
}

export async function fetchNews(country: string, category: string, date?: Date): Promise<NewsArticle[]> {
  const rssArticles = await fetchFromRSS(country);
  
  if (date) {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    const nextDate = new Date(targetDate);
    nextDate.setDate(nextDate.getDate() + 1);
    return rssArticles.filter(article => {
      if (!article.publishedAt) return false;
      const articleDate = new Date(article.publishedAt);
      return articleDate >= targetDate && articleDate < nextDate;
    });
  }

  return rssArticles.length > 0 ? rssArticles : getDemoNews(country, category, date);
}

export function getDemoNews(country: string, category: string, date?: Date): NewsArticle[] {
  const countryName = country.charAt(0).toUpperCase() + country.slice(1);
  const baseIndex = date ? date.getDate() : 0;
  const headlines = [
    `${countryName} Announces Major Economic Reform Package`,
    `Breaking: ${category.charAt(0).toUpperCase() + category.slice(1)} Sector Sees Record Growth in ${countryName}`,
    `${countryName} Tech Innovation Summit Draws Global Attention`,
    `Climate Initiative Launches in ${countryName}`,
    `${countryName} Cultural Festival Celebrates Diversity`,
    `Sports Championship Finals Set to Begin in ${countryName}`,
    `${countryName} Central Bank Adjusts Interest Rates`,
    `New Healthcare Initiative Expands Access in ${countryName}`,
    `${countryName} Education Reform Bill Passes`,
    `International Trade Agreement Signed with ${countryName}`,
  ];

  const sources = ['Global News Network', 'Daily Tribune', 'World Press', 'International Herald', 'National Observer'];
  const images = [
    'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&q=80',
    'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800&q=80',
    'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&q=80',
    'https://images.unsplash.com/photo-1569163139599-0f4517e36f51?w=800&q=80',
    'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&q=80',
  ];

  return headlines.slice(0, 8).map((title, i) => ({
    title,
    description: `Latest developments from ${countryName} regarding ${category} news and updates.`,
    url: '#',
    image: images[i % images.length],
    publishedAt: new Date(Date.now() - i * 3600000).toISOString(),
    source: sources[i % sources.length],
    author: null,
  }));
}
