interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
}

const requests: Map<string, number[]> = new Map();

export function checkRateLimit(key: string, config: RateLimitConfig): { allowed: boolean; remaining: number; resetTime: number } {
  const now = Date.now();
  const windowStart = now - config.windowMs;
  let keyRequests = requests.get(key) || [];
  keyRequests = keyRequests.filter(time => time > windowStart);

  if (keyRequests.length >= config.maxRequests) {
    return { allowed: false, remaining: 0, resetTime: keyRequests[0] + config.windowMs };
  }

  keyRequests.push(now);
  requests.set(key, keyRequests);
  return { allowed: true, remaining: config.maxRequests - keyRequests.length, resetTime: now + config.windowMs };
}

export const rateLimits = {
  login: { maxRequests: 5, windowMs: 300000 },
  signup: { maxRequests: 3, windowMs: 3600000 },
  passwordReset: { maxRequests: 3, windowMs: 3600000 },
  apiRequest: { maxRequests: 100, windowMs: 60000 },
  feedback: { maxRequests: 10, windowMs: 3600000 },
};

export function getRateLimitError(resetTime: number): string {
  const secondsLeft = Math.ceil((resetTime - Date.now()) / 1000);
  if (secondsLeft < 60) return `Too many requests. Please try again in ${secondsLeft} seconds.`;
  return `Too many requests. Please try again in ${Math.ceil(secondsLeft / 60)} minutes.`;
}
