export interface FeedbackData {
  type: 'bug' | 'feature' | 'general' | 'contact';
  name: string;
  email: string;
  subject: string;
  message: string;
}

export async function submitFeedback(data: FeedbackData): Promise<{ success: boolean; message: string }> {
  const feedbackData = {
    ...data,
    timestamp: new Date().toISOString(),
    page: window.location.href,
    userAgent: navigator.userAgent,
  };

  console.log('[Feedback] Submitting:', feedbackData);
  await new Promise(resolve => setTimeout(resolve, 1000));

  return {
    success: true,
    message: 'Thank you for your feedback! We will get back to you soon.',
  };
}

export const SUPPORT_EMAIL = 'support@globalnews.app';
export const CONTACT_EMAIL = 'contact@globalnews.app';
export const PRIVACY_EMAIL = 'privacy@globalnews.app';
